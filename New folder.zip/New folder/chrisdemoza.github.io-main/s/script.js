// Navigasi Smooth Scroll & Active Link
document.querySelectorAll('.nav-links a').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        window.scrollTo({
            top: target.offsetTop - 20,
            behavior: 'smooth'
        });
    });
});

window.addEventListener('scroll', () => {
    let current = "";
    const sections = document.querySelectorAll("section");
    const navItems = document.querySelectorAll(".nav-links li");

    sections.forEach(section => {
        const sectionTop = section.offsetTop;
        if (pageYOffset >= sectionTop - 60) {
            current = section.getAttribute("id");
        }
    });

    navItems.forEach(li => {
        li.classList.remove("active");
        if (li.querySelector('a').getAttribute('href').includes(current)) {
            li.classList.add("active");
        }
    });
});